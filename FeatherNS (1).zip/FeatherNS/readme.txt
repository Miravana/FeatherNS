===============================
Feather v3.0.0

Derivative extension of SweezeBreeze, with removed and added stuff, tailored towards raiders/tags

================================
KEY LIST:

R = Confirm WA join
S = Endorse
B = Visit Divide By Zero page, twice move back to DBZ
F = Move to region
A = Refresh
O = Ban
===============================

3.0
Removed mousetrap, rewritten to use pure javascript instead

---
2.2
Rewrote the script in Mousetrap due to the deprecation of the keyCode method as well as for code cleanliness sake, switched from jQuery in favor of Cash to save ~60KB
---
2.1
Updated to current Feather - Alterations Made By Miravana
Removed Dossier/Reports Functionality
Changed Keybinds and Regional Information
---
2.0 
Updated to current SweezeBreeze - Script By Sweeze
---
1.2
Re-arranged keys so less hand moving necessary.
Added icon.
---
1.1
added regional officer functionality
---
1.0
added confirm WA join feature
fixed join/resign feature
removed dossier+defender stuff
changed spear danes to plum island+le club des cinq
